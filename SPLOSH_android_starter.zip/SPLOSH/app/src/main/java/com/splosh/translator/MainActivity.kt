package com.splosh.translator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

data class LanguageItem(val code: String, val label: String)

class MainActivity : AppCompatActivity() {
    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner
    private lateinit var inputText: EditText
    private lateinit var resultText: TextView
    private lateinit var statusText: TextView
    private lateinit var translateButton: Button
    private var translator: Translator? = null

    private val languages = listOf(
        LanguageItem("ar", "العربية"),
        LanguageItem("en", "English"),
        LanguageItem("fr", "Français"),
        LanguageItem("es", "Español"),
        LanguageItem("de", "Deutsch"),
        LanguageItem("tr", "Türkçe"),
        LanguageItem("it", "Italiano"),
        LanguageItem("pt", "Português"),
        LanguageItem("ru", "Русский"),
        LanguageItem("zh", "中文"),
        LanguageItem("ja", "日本語"),
        LanguageItem("ko", "한국어"),
        LanguageItem("hi", "हिन्दी"),
        LanguageItem("ur", "اردو"),
        LanguageItem("fa", "فارسی"),
        LanguageItem("nl", "Nederlands"),
        LanguageItem("pl", "Polski"),
        LanguageItem("uk", "Українська"),
        LanguageItem("sv", "Svenska"),
        LanguageItem("el", "Ελληνικά"),
        LanguageItem("he", "עברית"),
        LanguageItem("bn", "বাংলা"),
        LanguageItem("id", "Bahasa Indonesia"),
        LanguageItem("vi", "Tiếng Việt"),
        LanguageItem("th", "ไทย"),
        LanguageItem("af", "Afrikaans"),
        LanguageItem("be", "Беларуская"),
        LanguageItem("bg", "Български"),
        LanguageItem("ca", "Català"),
        LanguageItem("cs", "Čeština"),
        LanguageItem("cy", "Cymraeg"),
        LanguageItem("da", "Dansk"),
        LanguageItem("eo", "Esperanto"),
        LanguageItem("et", "Eesti"),
        LanguageItem("fi", "Suomi"),
        LanguageItem("ga", "Gaeilge"),
        LanguageItem("gl", "Galego"),
        LanguageItem("gu", "ગુજરાતી"),
        LanguageItem("hr", "Hrvatski"),
        LanguageItem("ht", "Kreyòl ayisyen"),
        LanguageItem("hu", "Magyar"),
        LanguageItem("is", "Íslenska"),
        LanguageItem("ka", "ქართული"),
        LanguageItem("kn", "ಕನ್ನಡ"),
        LanguageItem("lt", "Lietuvių"),
        LanguageItem("lv", "Latviešu"),
        LanguageItem("mk", "Македонски"),
        LanguageItem("mr", "मराठी"),
        LanguageItem("ms", "Bahasa Melayu"),
        LanguageItem("mt", "Malti"),
        LanguageItem("no", "Norsk"),
        LanguageItem("ro", "Română"),
        LanguageItem("sk", "Slovenčina"),
        LanguageItem("sl", "Slovenščina"),
        LanguageItem("sq", "Shqip"),
        LanguageItem("sw", "Kiswahili"),
        LanguageItem("ta", "தமிழ்"),
        LanguageItem("te", "తెలుగు"),
        LanguageItem("tl", "Filipino")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sourceSpinner = findViewById(R.id.sourceLanguage)
        targetSpinner = findViewById(R.id.targetLanguage)
        inputText = findViewById(R.id.inputText)
        resultText = findViewById(R.id.resultText)
        statusText = findViewById(R.id.statusText)
        translateButton = findViewById(R.id.translateButton)

        val labels = languages.map { it.label }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        sourceSpinner.adapter = adapter
        targetSpinner.adapter = adapter
        sourceSpinner.setSelection(0)
        targetSpinner.setSelection(1)

        translateButton.setOnClickListener { translateText() }
        findViewById<TextView>(R.id.swapButton).setOnClickListener {
            val from = sourceSpinner.selectedItemPosition
            val to = targetSpinner.selectedItemPosition
            sourceSpinner.setSelection(to)
            targetSpinner.setSelection(from)
            val oldInput = inputText.text.toString()
            inputText.setText(resultText.text.toString().takeUnless { it == "ستظهر الترجمة هنا..." } ?: "")
            resultText.text = oldInput.ifBlank { "ستظهر الترجمة هنا..." }
        }
        findViewById<Button>(R.id.copyButton).setOnClickListener {
            val text = resultText.text.toString()
            if (text.isNotBlank() && text != "ستظهر الترجمة هنا...") {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("SPLOSH translation", text))
                Toast.makeText(this, "تم نسخ الترجمة", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener {
            inputText.text.clear()
            resultText.text = "ستظهر الترجمة هنا..."
            statusText.text = "اكتب نصاً جديداً للترجمة."
        }
    }

    private fun translateText() {
        val text = inputText.text.toString().trim()
        if (text.isEmpty()) {
            inputText.error = "اكتب النص أولاً"
            return
        }

        val source = languages[sourceSpinner.selectedItemPosition].code
        val target = languages[targetSpinner.selectedItemPosition].code
        if (source == target) {
            resultText.text = text
            statusText.text = "اللغتان متطابقتان."
            return
        }

        val sourceTag = TranslateLanguage.fromLanguageTag(source)
        val targetTag = TranslateLanguage.fromLanguageTag(target)
        if (sourceTag == null || targetTag == null) {
            statusText.text = "هذه اللغة غير مدعومة في محرك الترجمة الحالي."
            return
        }

        translator?.close()
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceTag)
            .setTargetLanguage(targetTag)
            .build()
        translator = Translation.getClient(options)

        translateButton.isEnabled = false
        statusText.text = "جارٍ تجهيز حزم اللغات. قد تحتاج اتصالاً بالإنترنت لأول مرة..."
        translator?.downloadModelIfNeeded(
            DownloadConditions.Builder().requireWifi().build()
        )?.addOnSuccessListener {
            statusText.text = "النماذج جاهزة. جارٍ الترجمة..."
            translator?.translate(text)
                ?.addOnSuccessListener { translated ->
                    resultText.text = translated
                    statusText.text = "اكتملت الترجمة. يمكنك استخدامها دون إنترنت بعد تنزيل النماذج."
                    translateButton.isEnabled = true
                    saveHistory(text, translated, source, target)
                }
                ?.addOnFailureListener { error ->
                    statusText.text = "تعذرت الترجمة: ${error.localizedMessage ?: "خطأ غير معروف"}"
                    translateButton.isEnabled = true
                }
        }?.addOnFailureListener { error ->
            statusText.text = "تعذر تنزيل نموذج اللغة. اتصل بالإنترنت وحاول مجدداً. ${error.localizedMessage ?: ""}"
            translateButton.isEnabled = true
        }
    }

    private fun saveHistory(original: String, translated: String, source: String, target: String) {
        val prefs = getSharedPreferences("splosh_history", Context.MODE_PRIVATE)
        val old = prefs.getString("items", "") ?: ""
        val row = listOf(source, target, original, translated).joinToString("|")
            .replace("\n", " ")
            .replace("|", " ")
        val updated = (row + "\n" + old).lines().take(30).joinToString("\n")
        prefs.edit().putString("items", updated).apply()
    }

    override fun onDestroy() {
        translator?.close()
        super.onDestroy()
    }
}
